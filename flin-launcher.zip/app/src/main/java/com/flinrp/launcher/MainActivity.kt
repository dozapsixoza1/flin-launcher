package com.flinrp.launcher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    companion object {
        const val CONFIG_URL = "https://raw.githubusercontent.com/dozapsixoza1/flin-launcher/main/version.json"
        const val SERVER_HOST = "195.18.27.226"
        const val SERVER_PORT = 3146
    }

    private lateinit var nick: EditText
    private lateinit var btn: Button
    private lateinit var bar: ProgressBar
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("launcher", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 4, pad, pad)
            setBackgroundColor(Color.parseColor("#121212"))
        }

        val title = TextView(this).apply {
            text = "FLIN RP"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        nick = EditText(this).apply {
            hint = "Ник (Имя_Фамилия)"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine()
            setText(prefs.getString("nick", ""))
        }
        btn = Button(this).apply {
            text = "ИГРАТЬ"
            setOnClickListener { onPlay() }
        }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
        }
        status = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            text = "Введи ник и нажми ИГРАТЬ"
        }

        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = pad }

        root.addView(title, lp)
        root.addView(nick, lp)
        root.addView(btn, lp)
        root.addView(bar, lp)
        root.addView(status, lp)
        setContentView(root)

    }

    private fun onPlay() {
        val name = nick.text.toString().trim()
        if (!Regex("^[A-Za-z0-9_\\[\\]]{3,24}\$").matches(name)) {
            status.text = "Ник: латиница, цифры и _ (3-24 символа)"
            return
        }
        prefs.edit().putString("nick", name).apply()
        btn.isEnabled = false

        Thread {
            try {
                prepare(name)
                runOnUiThread { launchClient() }
            } catch (e: Exception) {
                ui("Ошибка: ${e.message}")
            } finally {
                runOnUiThread { btn.isEnabled = true }
            }
        }.start()
    }

    private fun prepare(name: String) {
        val dir = getExternalFilesDir(null) ?: throw IOException("нет доступа к памяти")
        ui("Проверка обновлений...")
        val cfg = JSONObject(httpText(CONFIG_URL))
        val ver = cfg.getInt("version")
        val url = cfg.getString("cache_url")
        val have = prefs.getInt("cache_version", 0)

        dir.mkdirs()

        if (have != ver || !File(dir, "SAMP").exists()) {
            val tmp = File(dir, "cache.zip")
            download(url, tmp)
            ui("Распаковка...")
            unzip(tmp, dir)
            tmp.delete()
            prefs.edit().putInt("cache_version", ver).apply()
        }
        writeSettings(dir, name)
        ui("Готово, запуск...")
    }

    private fun httpText(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun download(url: String, out: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        val total = c.contentLengthLong
        c.inputStream.use { inp ->
            FileOutputStream(out).use { o ->
                val buf = ByteArray(65536)
                var n: Int
                var done = 0L
                var last = 0L
                while (inp.read(buf).also { n = it } != -1) {
                    o.write(buf, 0, n)
                    done += n
                    val now = System.currentTimeMillis()
                    if (now - last > 300) {
                        last = now
                        progress(done, total)
                    }
                }
            }
        }
    }

    private fun unzip(zip: File, dest: File) {
        val root = dest.canonicalPath + File.separator
        var count = 0
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val entryName = e.name.removePrefix("files/")
                if (entryName.isEmpty()) {
                    e = zin.nextEntry
                    continue
                }
                val f = File(dest, entryName)
                if (!f.canonicalPath.startsWith(root)) throw IOException("плохой zip")
                if (e.isDirectory) {
                    f.mkdirs()
                } else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { zin.copyTo(it) }
                }
                count++
                if (count % 20 == 0) ui("Распаковка... ($count)")
                e = zin.nextEntry
            }
        }
    }

    private fun writeSettings(dir: File, name: String) {
        val d = File(dir, "SAMP")
        d.mkdirs()
        val f = File(d, "settings.ini")
        if (!f.exists()) {
            f.writeText(
                "[client]\nname=$name\nhost=$SERVER_HOST\nport=$SERVER_PORT\n" +
                    "password=\nfps=60\n\n[debug]\ndebug=false\nonline=true\n\n" +
                    "[gui]\nFont=Arial.ttf\nFontSize=37.0\n"
            )
            return
        }
        val lines = f.readLines().toMutableList()
        var done = false
        for (i in lines.indices) {
            if (lines[i].trim().startsWith("name=")) {
                lines[i] = "name=$name"
                done = true
            }
        }
        if (!done) {
            val i = lines.indexOfFirst { it.trim() == "[client]" }
            if (i >= 0) {
                lines.add(i + 1, "name=$name")
            } else {
                lines.add("[client]")
                lines.add("name=$name")
            }
        }
        f.writeText(lines.joinToString("\n") + "\n")
    }

    private fun launchClient() {
        try {
            val orig = assets.open("orig_activity.txt").bufferedReader().use { it.readText() }.trim()
            val i = Intent()
            i.setClassName(packageName, orig)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            finish()
        } catch (e: Exception) {
            status.text = "Не удалось запустить игру: ${e.message}"
        }
    }

    private fun ui(text: String) {
        runOnUiThread {
            bar.isIndeterminate = false
            status.text = text
        }
    }

    private fun progress(done: Long, total: Long) {
        runOnUiThread {
            if (total > 0) {
                bar.isIndeterminate = false
                bar.progress = (done * 100 / total).toInt()
                status.text = "Скачивание ${done / 1048576} / ${total / 1048576} МБ"
            } else {
                bar.isIndeterminate = true
                status.text = "Скачивание ${done / 1048576} МБ"
            }
        }
    }
}
