package com.flinrp.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Random
import java.util.zip.ZipInputStream
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class BgView(ctx: Context) : View(ctx) {
    private class Dot(var x: Float, var y: Float, val r: Float, val sp: Float, val a: Int)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(7)
    private val dots = ArrayList<Dot>()
    private var t = 0f
    private val blob = intArrayOf(0x7C3AED, 0x22D3EE, 0xF472B6)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 24000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        dots.clear()
        for (i in 0 until 70) {
            dots.add(
                Dot(
                    rnd.nextFloat() * w, rnd.nextFloat() * h,
                    1f + rnd.nextFloat() * 2.2f, 0.25f + rnd.nextFloat() * 0.9f,
                    60 + rnd.nextInt(150)
                )
            )
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(0xFF07060D.toInt(), 0xFF140B2E.toInt(), 0xFF07060D.toInt()),
            null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, paint)
        for (i in 0 until 3) {
            val ang = t * 6.2832f + i * 2.1f
            val cx = w * (0.2f + 0.3f * i) + cos(ang) * w * 0.07f
            val cy = h * (0.3f + 0.25f * i) + sin(ang + 1f) * h * 0.1f
            val r = h * (0.8f + 0.1f * i)
            paint.shader = RadialGradient(
                cx, cy, r, (0x55 shl 24) or blob[i], 0x00000000, Shader.TileMode.CLAMP
            )
            c.drawCircle(cx, cy, r, paint)
        }
        paint.shader = null
        for (d in dots) {
            d.y -= d.sp
            if (d.y < -8f) {
                d.y = h + 8f
                d.x = rnd.nextFloat() * w
            }
            paint.color = Color.argb(d.a, 200, 192, 255)
            c.drawCircle(d.x + sin(t * 6.2832f * 3f + d.r * 5f) * 6f, d.y, d.r, paint)
        }
        paint.shader = RadialGradient(
            w / 2f, h / 2f, max(w, h) * 0.75f,
            0x00000000, 0xCC000000.toInt(), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, paint)
    }
}

class BarView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var target = 0f
    private var shown = 0f
    private var phase = 0f
    var indeterminate = false
        set(v) {
            field = v
            invalidate()
        }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1500
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            shown += (target - shown) * 0.15f
            invalidate()
        }
    }

    fun setProgress(v: Float) {
        target = v.coerceIn(0f, 1f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        paint.shader = null
        paint.color = 0x22FFFFFF
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, paint)
        var l = 0f
        var rr = w * shown
        if (indeterminate) {
            val fw = w * 0.3f
            l = max((w + fw) * phase - fw, 0f)
            rr = min((w + fw) * phase, w)
        }
        if (rr - l < 1f) return
        paint.shader = LinearGradient(
            0f, 0f, w, 0f,
            intArrayOf(0xFF7C3AED.toInt(), 0xFF22D3EE.toInt(), 0xFFF472B6.toInt()),
            null, Shader.TileMode.CLAMP
        )
        rect.set(l, 0f, rr, h)
        c.drawRoundRect(rect, r, r, paint)
        val sx = w * ((phase * 1.6f) % 1f)
        paint.shader = LinearGradient(
            sx - 50f, 0f, sx + 50f, 0f,
            intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(rect, r, r, paint)
    }
}

class CountingStream(inp: InputStream, private val onBytes: (Long) -> Unit) : FilterInputStream(inp) {
    private var total = 0L

    override fun read(): Int {
        val b = super.read()
        if (b >= 0) add(1L)
        return b
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val n = super.read(b, off, len)
        if (n > 0) add(n.toLong())
        return n
    }

    private fun add(n: Long) {
        total += n
        onBytes(total)
    }
}

class MainActivity : Activity() {

    companion object {
        const val CONFIG_URL = "https://raw.githubusercontent.com/dozapsixoza1/flin-launcher/main/version.json"
        const val SERVER_HOST = "195.18.27.226"
        const val SERVER_PORT = 3146
    }

    private lateinit var nick: EditText
    private lateinit var play: TextView
    private lateinit var bar: BarView
    private lateinit var status: TextView
    private lateinit var percent: TextView
    private var busy = false
    private val prefs by lazy { getSharedPreferences("launcher", Context.MODE_PRIVATE) }
    private val embedded: Boolean by lazy {
        try {
            assets.open("orig_activity.txt").close()
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
    private fun dpi(v: Float): Int = (dp(v) + 0.5f).toInt()

    private fun label(txt: String, size: Float, color: String): TextView {
        val v = TextView(this)
        v.text = txt
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        v.setTextColor(Color.parseColor(color))
        return v
    }

    private fun chip(txt: String): TextView {
        val v = label(txt, 13f, "#D8D4F5")
        v.setPadding(dpi(14f), dpi(7f), dpi(14f), dpi(7f))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#12FFFFFF"))
        bg.setStroke(dpi(1f), Color.parseColor("#38FFFFFF"))
        bg.cornerRadius = dp(20f)
        v.background = bg
        return v
    }

    private fun fieldBg(focus: Boolean): GradientDrawable {
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#4D000000"))
        bg.setStroke(
            dpi(1.5f),
            Color.parseColor(if (focus) "#22D3EE" else "#44FFFFFF")
        )
        bg.cornerRadius = dp(14f)
        return bg
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#07060D"))
        root.addView(BgView(this), FrameLayout.LayoutParams(-1, -1))

        val content = LinearLayout(this)
        content.orientation = LinearLayout.HORIZONTAL
        content.gravity = Gravity.CENTER_VERTICAL
        content.setPadding(dpi(48f), dpi(16f), dpi(48f), dpi(16f))
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.gravity = Gravity.CENTER_VERTICAL
        content.addView(left, LinearLayout.LayoutParams(0, -2, 1.15f))

        val logo = label("FLIN RP", 58f, "#FFFFFF")
        logo.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        logo.letterSpacing = 0.04f
        logo.setShadowLayer(dp(18f), 0f, 0f, Color.parseColor("#998B5CF6"))
        shimmer(logo)
        left.addView(logo)

        val sub = label("Role play · SA-MP", 14f, "#9A96B5")
        sub.letterSpacing = 0.2f
        left.addView(sub)

        val chipParams = LinearLayout.LayoutParams(-2, -2)
        chipParams.topMargin = dpi(14f)
        left.addView(chip("Сервер 01"), chipParams)
        val chipParams2 = LinearLayout.LayoutParams(-2, -2)
        chipParams2.topMargin = dpi(8f)
        left.addView(chip("$SERVER_HOST:$SERVER_PORT"), chipParams2)

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.gravity = Gravity.CENTER
        content.addView(right, LinearLayout.LayoutParams(0, -1, 1f))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dpi(20f), dpi(14f), dpi(20f), dpi(14f))
        val cbg = GradientDrawable()
        cbg.setColor(Color.parseColor("#12FFFFFF"))
        cbg.setStroke(dpi(1f), Color.parseColor("#33FFFFFF"))
        cbg.cornerRadius = dp(22f)
        card.background = cbg
        right.addView(card, LinearLayout.LayoutParams(-1, -2))

        val cap = label("Вход в игру", 12f, "#9A96B5")
        cap.letterSpacing = 0.1f
        card.addView(cap)

        nick = EditText(this)
        nick.hint = "Ник (Имя_Фамилия)"
        nick.setHintTextColor(Color.parseColor("#77FFFFFF"))
        nick.setTextColor(Color.WHITE)
        nick.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        nick.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        nick.setSingleLine()
        nick.imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        nick.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(24))
        nick.setPadding(dpi(14f), dpi(10f), dpi(14f), dpi(10f))
        nick.background = fieldBg(false)
        nick.setText(prefs.getString("nick", ""))
        nick.setOnFocusChangeListener { _, f -> nick.background = fieldBg(f) }
        val nickParams = LinearLayout.LayoutParams(-1, -2)
        nickParams.topMargin = dpi(8f)
        card.addView(nick, nickParams)

        play = label("ИГРАТЬ", 18f, "#FFFFFF")
        play.typeface = Typeface.DEFAULT_BOLD
        play.letterSpacing = 0.2f
        play.gravity = Gravity.CENTER
        val pbg = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                Color.parseColor("#7C3AED"),
                Color.parseColor("#22D3EE"),
                Color.parseColor("#F472B6")
            )
        )
        pbg.cornerRadius = dp(16f)
        play.background = pbg
        play.elevation = dp(8f)
        play.isClickable = true
        play.setOnClickListener { onPlay() }
        play.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(80).start()
            } else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
        val playParams = LinearLayout.LayoutParams(-1, dpi(50f))
        playParams.topMargin = dpi(14f)
        card.addView(play, playParams)

        val pulse = ValueAnimator.ofFloat(0.88f, 1f)
        pulse.duration = 900
        pulse.repeatMode = ValueAnimator.REVERSE
        pulse.repeatCount = ValueAnimator.INFINITE
        pulse.addUpdateListener {
            if (!busy) play.alpha = it.animatedValue as Float
        }
        pulse.start()

        bar = BarView(this)
        val barParams = LinearLayout.LayoutParams(-1, dpi(8f))
        barParams.topMargin = dpi(18f)
        card.addView(bar, barParams)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        status = label("Введи ник и нажми ИГРАТЬ", 13f, "#B8B4D6")
        percent = label("", 13f, "#22D3EE")
        percent.typeface = Typeface.DEFAULT_BOLD
        row.addView(status, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(percent)
        val rowParams = LinearLayout.LayoutParams(-1, -2)
        rowParams.topMargin = dpi(8f)
        card.addView(row, rowParams)

        val logBtn = label("Скопировать лог", 12f, "#9A96B5")
        logBtn.setPadding(0, dpi(10f), 0, 0)
        logBtn.paintFlags = logBtn.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        logBtn.setOnClickListener { copyLog() }
        card.addView(logBtn)

        left.alpha = 0f
        left.translationX = -dp(40f)
        card.alpha = 0f
        card.translationX = dp(40f)
        left.animate().alpha(1f).translationX(0f).setDuration(700)
            .setStartDelay(150).setInterpolator(DecelerateInterpolator()).start()
        card.animate().alpha(1f).translationX(0f).setDuration(700)
            .setStartDelay(350).setInterpolator(DecelerateInterpolator()).start()

        setContentView(root)
        hideBars()
    }

    private fun shimmer(tv: TextView) {
        val wpx = dp(300f)
        val sh = LinearGradient(
            0f, 0f, wpx, 0f,
            intArrayOf(
                Color.parseColor("#22D3EE"),
                Color.parseColor("#8B5CF6"),
                Color.parseColor("#F472B6"),
                Color.parseColor("#22D3EE")
            ),
            null, Shader.TileMode.MIRROR
        )
        tv.paint.shader = sh
        val m = Matrix()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 4000
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            m.setTranslate(wpx * 2f * (it.animatedValue as Float), 0f)
            sh.setLocalMatrix(m)
            tv.invalidate()
        }
        a.start()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    private fun say(text: String, err: Boolean) {
        runOnUiThread {
            bar.indeterminate = false
            if (err) percent.text = ""
            status.text = text
            status.setTextColor(Color.parseColor(if (err) "#FF7A90" else "#B8B4D6"))
        }
    }

    private fun step(text: String) {
        runOnUiThread {
            bar.indeterminate = true
            percent.text = ""
            status.text = text
            status.setTextColor(Color.parseColor("#B8B4D6"))
        }
    }

    private fun setProgress(f: Float) {
        bar.setProgress(f)
        percent.text = "${(f * 100f).toInt()}%"
    }

    private fun setBusy(b: Boolean) {
        runOnUiThread {
            busy = b
            play.text = if (b) "ЗАГРУЗКА…" else "ИГРАТЬ"
            play.alpha = if (b) 0.6f else 1f
        }
    }

    private fun onPlay() {
        if (busy) return
        val name = nick.text.toString().trim()
        if (!Regex("^[A-Za-z0-9_\\[\\]]{3,24}\$").matches(name)) {
            say("Ник: латиница, цифры и _ (3-24 символа)", true)
            return
        }
        prefs.edit().putString("nick", name).apply()
        setBusy(true)
        if (!embedded) {
            demo()
            return
        }
        Thread {
            try {
                val warn = prepare(name)
                if (warn != null) {
                    say(warn, true)
                } else {
                    runOnUiThread {
                        Handler(Looper.getMainLooper()).postDelayed({ launchClient() }, 1500)
                    }
                }
            } catch (e: Exception) {
                say("Ошибка: ${e.message}", true)
            } finally {
                setBusy(false)
            }
        }.start()
    }

    private fun demo() {
        say("Демо: имитация загрузки", false)
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 2600
        a.addUpdateListener { setProgress(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                say("Демо-режим: игра не встроена в этот APK", false)
                setBusy(false)
            }
        })
        a.start()
    }

    private fun prepare(name: String): String? {
        val dir = getExternalFilesDir(null) ?: throw IOException("нет доступа к памяти")
        val obb = obbDir
        step("Проверка обновлений...")
        val cfg = JSONObject(httpText(CONFIG_URL))
        val ver = cfg.getInt("version")
        val url = cfg.getString("cache_url")
        val have = prefs.getInt("cache_version", 0)

        dir.mkdirs()
        obb.mkdirs()
        var warn: String? = null
        if (have != ver) {
            val res = downloadAndUnzip(url, dir, obb)
            prefs.edit().putInt("cache_version", ver).apply()
            if (res.second == 0) {
                warn = "В архиве нет .obb (файлов: ${res.first}). Нажми ИГРАТЬ ещё раз, чтобы запустить"
            }
        }
        writeSettings(dir, name)
        runOnUiThread {
            bar.indeterminate = false
            setProgress(1f)
            status.text = "Готово, запуск..."
        }
        return warn
    }

    private fun httpText(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun progress(done: Long, total: Long) {
        runOnUiThread {
            if (total > 0) {
                bar.indeterminate = false
                setProgress(done.toFloat() / total.toFloat())
                status.text = "Загрузка ${done / 1048576} / ${total / 1048576} МБ"
            } else {
                bar.indeterminate = true
                status.text = "Загрузка ${done / 1048576} МБ"
            }
        }
    }

    private fun downloadAndUnzip(url: String, dir: File, obb: File): Pair<Int, Int> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.instanceFollowRedirects = true
        val total = c.contentLengthLong
        var last = 0L
        val cs = CountingStream(c.inputStream) { done ->
            val now = System.currentTimeMillis()
            if (now - last > 250) {
                last = now
                progress(done, total)
            }
        }
        val root = dir.canonicalPath + File.separator
        var files = 0
        var obbs = 0
        ZipInputStream(BufferedInputStream(cs, 65536)).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val entryName = e.name.removePrefix("files/")
                if (entryName.isNotEmpty()) {
                    if (e.isDirectory) {
                        val d = File(dir, entryName)
                        if (d.canonicalPath.startsWith(root)) d.mkdirs()
                    } else {
                        val base = entryName.substringAfterLast('/')
                        val target: File
                        if (base.endsWith(".obb", true)) {
                            target = File(obb, base)
                            obbs++
                        } else {
                            target = File(dir, entryName)
                            if (!target.canonicalPath.startsWith(root)) throw IOException("плохой zip")
                        }
                        target.parentFile?.mkdirs()
                        FileOutputStream(target).use { zin.copyTo(it, 65536) }
                        files++
                    }
                }
                e = zin.nextEntry
            }
        }
        return Pair(files, obbs)
    }

    private fun writeSettings(dir: File, name: String) {
        val d = File(dir, "SAMP")
        d.mkdirs()
        val f = File(d, "settings.ini")
        if (!f.exists()) {
            f.writeText(
                "[client]\nname=$name\nhost=$SERVER_HOST\nport=$SERVER_PORT\n" +
                    "password=\nfps=60\n\n[debug]\ndebug=false\nonline=true\n\n" +
                    "[gui]\nFont=Arial.ttf\nFontSize=37.0\n"
            )
            return
        }
        val lines = f.readLines().toMutableList()
        var done = false
        for (i in lines.indices) {
            if (lines[i].trim().startsWith("name=")) {
                lines[i] = "name=$name"
                done = true
            }
        }
        if (!done) {
            val i = lines.indexOfFirst { it.trim() == "[client]" }
            if (i >= 0) {
                lines.add(i + 1, "name=$name")
            } else {
                lines.add("[client]")
                lines.add("name=$name")
            }
        }
        f.writeText(lines.joinToString("\n") + "\n")
    }

    private fun collectLog(): String {
        val sb = StringBuilder()
        sb.append("Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n")
        sb.append("Device ${Build.MANUFACTURER} ${Build.MODEL}\n")
        sb.append("ABIs ${Build.SUPPORTED_ABIS.joinToString(",")}\n")
        sb.append("Package $packageName\n\n")
        val dir = getExternalFilesDir(null)
        if (dir != null) {
            val g = File(dir, "SAMP/samp_log.txt")
            sb.append("=== SAMP/samp_log.txt ===\n")
            if (g.exists()) {
                sb.append(g.readLines().takeLast(80).joinToString("\n")).append("\n")
            } else {
                sb.append("(нет файла)\n")
            }
            val sf = File(dir, "SAMP/settings.ini")
            sb.append("\n=== settings.ini ===\n")
            sb.append(if (sf.exists()) sf.readText() else "(нет файла)").append("\n")
        }
        sb.append("\n=== logcat ===\n")
        try {
            val p = Runtime.getRuntime().exec(arrayOf("logcat", "-d", "-t", "3000", "-v", "time"))
            val lines = p.inputStream.bufferedReader().readLines()
            val keys = listOf(
                "FATAL", "AndroidRuntime", "SIGSEGV", "SIGABRT", "signal ", "backtrace",
                "Abort", "UnsatisfiedLink", "libsamp", "libGTASA", "DEBUG", "tombstone",
                "GTASA", "samp", "Exception", "Error"
            )
            val f = lines.filter { l -> keys.any { k -> l.contains(k, true) } }
            sb.append(f.takeLast(150).joinToString("\n"))
        } catch (e: Exception) {
            sb.append("logcat error: ${e.message}")
        }
        return sb.toString()
    }

    private fun copyLog() {
        say("Собираю лог...", false)
        Thread {
            try {
                val text = collectLog()
                val clip = if (text.length > 90000) text.takeLast(90000) else text
                val dir = getExternalFilesDir(null)
                if (dir != null) File(dir, "launcher_log.txt").writeText(clip)
                runOnUiThread {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("log", clip))
                    status.text = "Лог скопирован (${clip.length} симв.). Вставь его в чат"
                    status.setTextColor(Color.parseColor("#B8B4D6"))
                }
            } catch (e: Exception) {
                say("Ошибка лога: ${e.message}", true)
            }
        }.start()
    }

    private fun launchClient() {
        try {
            val orig = assets.open("orig_activity.txt").bufferedReader().use { it.readText() }.trim()
            val i = Intent()
            i.setClassName(packageName, orig)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            finish()
        } catch (e: Exception) {
            say("Не удалось запустить игру: ${e.message}", true)
        }
    }
}
